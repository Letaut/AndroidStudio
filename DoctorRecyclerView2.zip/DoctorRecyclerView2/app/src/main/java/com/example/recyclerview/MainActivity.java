package com.example.recyclerview;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    String String1[], String2[];
    int[] images = {R.drawable.doctor1,
            R.drawable.doctor2,
            R.drawable.doctor1,
            R.drawable.doctor1,
            R.drawable.doctor2,
            R.drawable.doctor1,
            R.drawable.doctor1,
            R.drawable.doctor2,
            R.drawable.doctor1,
            R.drawable.doctor1,
            R.drawable.doctor2};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerview_doctors);
        String1 = getResources().getStringArray(R.array.names);
        String2 = getResources().getStringArray(R.array.description);
        DoctorAdapter doctorAdapter = new DoctorAdapter(this, String1, String2,images);
        recyclerView.setAdapter(doctorAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

     }
     public void click(View view){
        Button callButton = findViewById(R.id.phoneCall);
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:0755901258"));
        startActivity(intent);
     }

}