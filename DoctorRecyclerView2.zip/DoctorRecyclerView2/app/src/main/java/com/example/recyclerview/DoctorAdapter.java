package com.example.recyclerview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class DoctorAdapter extends RecyclerView.Adapter<DoctorAdapter.DoctorViewHolder> {
    int images[];
    Context context;
    String field1[], field2[];


    public DoctorAdapter(Context context1, String string1[], String string2[], int image[]){
        context = context1;
        field1 = string1;
        field2 = string2;
        images = image;
    }

    @NonNull
    @Override
    public DoctorViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        View view = layoutInflater.inflate
                (R.layout.doctor_item,parent,false);
        return new DoctorViewHolder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull DoctorViewHolder holder, int position) {
        holder.name.setText(field1[position]);
        holder.description.setText(field2[position]);
        holder.image.setImageResource(images[position]);
    }
    @Override
    public int getItemCount() {
        return field1.length;
    }
    public class DoctorViewHolder extends RecyclerView.ViewHolder{

        TextView name, description;
        ImageView image;
        public DoctorViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.textview_name);
            description = itemView.findViewById(R.id.textview_description);
            image = itemView.findViewById(R.id.image_doctor);
        }
    }

}
